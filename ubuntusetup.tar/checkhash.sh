#!/bin/sh -x

cd /home/sdxtlhy

#判斷ipfs是否在運行,如未運行，則啓動ipfs daemon
while :; do
   PIDS=`ps -ef | grep "ipfs"|grep -v grep|awk '{print $2}'`
   RETSTR="ret$PIDS"
   if  [ $RETSTR = "ret" ]; then 
     ipfs daemon &
     sleep 5
   else
     break
   fi
done

#獲取最新hash
#while :; do
  ipfs name resolve -n QmSeJ41iXwebzm3KPTixBc3zoetBD61df76BRjE4RuY4YB >curhash.dat
  RETV=$?
  if  test $RETV -eq 0 ; then 
     break
  else
     echo "獲取最新hash失敗"
     echo "獲取最新hash失敗 $RETV" >mylog.txt
     exit 1
  fi
#done
cat curhash.dat

UPDATE_HASH="true"
EXIST_OLD="false"
if [ -e oldhash.dat ]; then
  cmp oldhash.dat curhash.dat
  RETV=$?
  if  test $RETV -eq 0 ; then
     UPDATE_HASH="false"
  else
     EXIST_OLD="true"
  fi
fi

REBOOTIPFS="false"

if [ $UPDATE_HASH = "true" ];then
     ipfs pin add <curhash.dat
     RETV=$?
     if  test $RETV -eq 0 ; then
       if [ $EXIST_OLD = "true" ];then
          ipfs pin rm <oldhash.dat
          rm oldhash.dat
       fi
       mv curhash.dat oldhash.dat
       cat cmdtxt.dat oldhash.dat >setmain.sh
       chmod +x setmain.sh
       cat setmain.sh
       ./setmain.sh
       REBOOTIPFS="true"
     fi
fi

ipfs pin add <oldhash.dat

if [ $REBOOTIPFS = "true" ];then
killall ipfs

#等待成功關閉ipfs daemon
while :; do
   sleep 5
   PIDS=`ps -ef | grep "ipfs"|grep -v grep|awk '{print $2}'`
   RETSTR="ret$PIDS"
   if  [ $RETSTR = "ret" ] ; then 
     break
   fi
done

#等待成功啓動ipfs daemon
while :; do
   PIDS=`ps -ef | grep "ipfs"|grep -v grep|awk '{print $2}'`
   RETSTR="ret$PIDS"
   if  [ $RETSTR = "ret" ]; then 
     ipfs daemon &
     sleep 10
   else
     break
   fi
done
fi

if [ -e ipns.id ]; then
  ipfs dht get /pk/QmSeJ41iXwebzm3KPTixBc3zoetBD61df76BRjE4RuY4YB >pk.dat
  ipfs dht get /ipns/QmSeJ41iXwebzm3KPTixBc3zoetBD61df76BRjE4RuY4YB >ipns.dat
  ipfs dht put /pk/QmSeJ41iXwebzm3KPTixBc3zoetBD61df76BRjE4RuY4YB <pk.dat >/dev/null
  ipfs dht put /ipns/QmSeJ41iXwebzm3KPTixBc3zoetBD61df76BRjE4RuY4YB <ipns.dat >/dev/null
fi

