tar -cf ubuntusetup.tar checkhash.sh startipfs.sh cmdtxt.dat config etc/crontab etc/rc.local createubuntusetup.tar.sh

