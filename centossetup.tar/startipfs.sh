#!/bin/sh

rm /root/checkhash.runing
/usr/local/bin/ipfs daemon &
phddns start
firewall-cmd --add-port=8080/tcp
firewall-cmd --add-port=5001/tcp

