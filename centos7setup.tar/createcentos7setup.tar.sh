tar -cf centos7setup.tar checkhash.sh startipfs.sh cmdtxt.dat config etc/crontab etc/rc.local etc/rc.d/rc.local createcentos7setup.tar.sh

