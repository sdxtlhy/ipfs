#!/bin/sh

#如存在checkhash.runing,则判断是否运行时间过长，超过指定时间，则认为异常，进行清理
if [ -e checkhash.runing ];then
  query_start_time_timestamp=`cat checkhash.runing|awk '{print$1}'`
  timestrlen=${#query_start_time_timestamp}
  if test $timestrlen -lt 8
  then
      query_start_time_timestamp="100000"
  fi
  query_end_time=`date +"%Y-%m-%d %H:%M:%S"`
  query_end_time_timestamp=`date -d "$query_end_time" +%s`
  query_time_time_consuming=`expr $query_end_time_timestamp - $query_start_time_timestamp`

  if test $query_time_time_consuming -lt  72000
   then
     echo runing...
     exit 1
   fi
   #判断超时20小时则清理
   rm checkhash.runing
   #清理所有chechkhash.sh,ipfs pin add 进程
   for i in `ps -ef | grep "ipfs"|grep -v "ipfs daemon"|grep -v "grep"|awk '{print $2}'`; do kill -9 $i; done;
   for i in `ps -ef | grep "checkhash.sh"|grep -v $$|grep -v "grep"|awk '{print $2}'`; do kill -9 $i; done;
fi

query_start_time=`date +"%Y-%m-%d %H:%M:%S"`
query_start_time_timestamp=`date -d "$query_start_time" +%s`
echo $query_start_time_timestamp >checkhash.runing


#判斷ipfs是否在運行,如未運行，則啓動ipfs daemon
while :; do
   PIDS=`ps -ef | grep "ipfs daemon"|grep -v grep|awk '{print $2}'`
   RETSTR="ret$PIDS"
   if  [ $RETSTR = "ret" ]; then 
     ipfs daemon &
     sleep 5
   else
     break
   fi
done

#獲取最新hash
while :; do
  ipfs name resolve -n QmSeJ41iXwebzm3KPTixBc3zoetBD61df76BRjE4RuY4YB >curhash.dat
  RETV=$?
  if  test $RETV -eq 0 ; then 
     break
  else
     echo "獲取最新hash失敗 $RETV" >mylog.txt
     sleep 5
  fi
done
cat curhash.dat

UPDATE_HASH="true"
EXIST_OLD="false"
if [ -e oldhash.dat ]; then
  cmp oldhash.dat curhash.dat
  RETV=$?
  if  test $RETV -eq 0 ; then
     UPDATE_HASH="false"
  else
     EXIST_OLD="true"
  fi
fi

REBOOTIPFS="false"

if [ $UPDATE_HASH = "true" ];then
     ipfs pin add <curhash.dat
     RETV=$?
     if  test $RETV -eq 0 ; then
       if [ $EXIST_OLD = "true" ];then
          ipfs pin rm <oldhash.dat
          rm oldhash.dat
       fi
       mv curhash.dat oldhash.dat
       cat cmdtxt.dat oldhash.dat >setmain.sh
       chmod +x setmain.sh
       cat setmain.sh
       ./setmain.sh
       REBOOTIPFS="true"
     fi
fi

ipfs pin add <oldhash.dat

if [ $REBOOTIPFS = "true" ];then
killall ipfs

#等待成功關閉ipfs daemon
while :; do
   sleep 5
   PIDS=`ps -ef | grep "ipfs daemon"|grep -v grep|awk '{print $2}'`
   RETSTR="ret$PIDS"
   if  [ $RETSTR = "ret" ] ; then 
     break
   fi
done

#等待成功啓動ipfs daemon
while :; do
   PIDS=`ps -ef | grep "ipfs daemon"|grep -v grep|awk '{print $2}'`
   RETSTR="ret$PIDS"
   if  [ $RETSTR = "ret" ]; then 
     ipfs daemon &
     sleep 10
   else
     break
   fi
done
fi

#獲取最新hash
while :; do
  ipfs name resolve -n QmSeJ41iXwebzm3KPTixBc3zoetBD61df76BRjE4RuY4YB >curhash.dat
  RETV=$?
  if  test $RETV -eq 0 ; then
     break
  else
     echo "獲取最新hash失敗 $RETV" >mylog.txt
     sleep 5
  fi
done

if [ -e ipns.id ]; then
  ipfs dht get /pk/QmSeJ41iXwebzm3KPTixBc3zoetBD61df76BRjE4RuY4YB >pk.dat
  ipfs dht get /ipns/QmSeJ41iXwebzm3KPTixBc3zoetBD61df76BRjE4RuY4YB >ipns.dat
  ipfs dht put /pk/QmSeJ41iXwebzm3KPTixBc3zoetBD61df76BRjE4RuY4YB <pk.dat >/dev/null
  ipfs dht put /ipns/QmSeJ41iXwebzm3KPTixBc3zoetBD61df76BRjE4RuY4YB <ipns.dat >/dev/null
fi
rm checkhash.runing
